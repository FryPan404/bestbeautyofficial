

<!-- start page title -->
<div class="page-title-box">
    <div class="container-fluid">
     <div class="row align-items-center">
         <div class="col-sm-6">
             <div class="page-title">
                 <h4><?= $title;?></h4>
                     <ol class="breadcrumb m-0">
                         <li class="breadcrumb-item"><a href="<?= base_url();?>#admin/dashboard">Home</a></li>
                         <li class="breadcrumb-item active"><?= $title;?></li>
                     </ol>
             </div>
         </div>
         <div class="col-sm-6">
            <div class="float-end d-none d-sm-block">
                <a href="javascript:void(0)" onclick="window.history.back()" class="btn btn-success waves-effect waves-light"><i class="fas fa-arrow-left"></i> Back</a>
                <a href="javascript:void(0)" class="btn btn-warning waves-effect waves-light btn-refresh"><i class="fas fa-sync"></i></a>
            </div>
         </div>
     </div>
    </div>
 </div>
 <!-- end page title -->    


<div class="container-fluid">
    <div class="page-content-wrapper">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <form action="" method="POST" id="form_profile">
                          <div class="row mb-3">
                            <p>Manage your account here. Please dont lose your password!</p>
                          </div>
                          <div class="row mb-3">
                              <label for="" class="col-sm-2 col-form-label">Employee ID</label>
                              <div class="col-sm-10">
                                  <input class="form-control" required type="text" placeholder="" name="name">
                              </div>
                          </div>
                          <div class="row mb-3">
                              <label for="" class="col-sm-2 col-form-label">Name</label>
                              <div class="col-sm-10">
                                  <input class="form-control" required type="text" placeholder="" name="name">
                              </div>
                          </div>
                          <div class="row mb-3">
                              <label for="" class="col-sm-2 col-form-label">Email</label>
                              <div class="col-sm-10">
                                  <input class="form-control" required type="text" placeholder="" name="name">
                              </div>
                          </div>
                          <div class="row mb-3">
                              <label for="" class="col-sm-2 col-form-label">Username</label>
                              <div class="col-sm-10">
                                  <input class="form-control" readonly type="text">
                              </div>
                          </div>
                          <div class="row mb-3">
                              <label for="" class="col-sm-2 col-form-label">User Level</label>
                              <div class="col-sm-10">
                                  <input class="form-control" readonly type="text" value="Superadmin">
                              </div>
                          </div>
                          <div class="row mb-3">
                              <label for="" class="col-sm-2 col-form-label">Plant Location</label>
                              <div class="col-sm-10">
                                  <input class="form-control" readonly type="text" value="Tuban Plant">
                              </div>
                          </div>
                          <div class="row mb-3">
                              <label for="" class="col-sm-2 col-form-label">Status</label>
                              <div class="col-sm-10">
                                  <input class="form-control" readonly type="text" value="Active">
                              </div>
                          </div>
                          <div class="row mb-3">
                              <label for="" class="col-sm-2 col-form-label">Old Password</label>
                              <div class="col-sm-10">
                                  <input class="form-control" name="password" type="password" placeholder="********">
                              </div>
                          </div>
                          <div class="row mb-3">
                              <label for="" class="col-sm-2 col-form-label">New Password</label>
                              <div class="col-sm-10">
                                  <input class="form-control" name="new_password" type="password" placeholder="********">
                              </div>
                          </div>
                          <div class="row mb-3">
                              <label for="" class="col-sm-2 col-form-label">Confirm New Password</label>
                              <div class="col-sm-10">
                                  <input class="form-control" name="new_password" type="password" placeholder="********">
                              </div>
                          </div>
                          <div class="mb-3 text-right">
                              <a href="javascript:void(0)" class="btn btn-default btn-back"><i class="fas fa-arrow-left"></i> Cancel</a>
                              <a href="javascript:void(0)" class="btn btn-primary" id="btn_save"><i class="fas fa-save"></i> Save Changes</a>
                          </div>
                        </form>
                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->
    </div>
</div> <!-- container-fluid -->