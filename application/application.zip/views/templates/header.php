<?php
date_default_timezone_set("Asia/Jakarta");
?>
<!doctype html>
<html lang="en">

    <head>
        
        
        <meta charset="utf-8" />
        <title><?= master_title();?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="" name="description" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="<?= base_url();?>assets/images/favicon.png">

        <!-- Bootstrap Css -->
        <link href="<?= base_url();?>assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
        <!-- Icons Css -->
        <link href="<?= base_url();?>assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <!-- Sweet Alert-->
        <link href="<?= base_url();?>assets/libs/sweetalert2/sweetalert2.min.css" rel="stylesheet" type="text/css" />
        <!-- DataTables -->
        <link href="<?= base_url();?>assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
        <link href="<?= base_url();?>assets/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />
        <!-- Responsive datatable examples -->
        <link href="<?= base_url();?>assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />
        <!-- App Css-->
        <link href="<?= base_url();?>assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />


        <style type="text/css">
            .modal-content{
                
            }

            tr,td{
                padding: 6px 5px 5px 5px !important;
            }

            ::placeholder { /* Chrome, Firefox, Opera, Safari 10.1+ */
              color: #ddd !important;
              opacity: 1; /* Firefox */
            }

            :-ms-input-placeholder { /* Internet Explorer 10-11 */
              color: #ddd !important;
            }

            ::-ms-input-placeholder { /* Microsoft Edge */
              color: #ddd !important;
            }

            .tox-tinymce-aux {
                z-index: 99999999 !important;
            }

            .text-right{
                text-align: right !important;
            }

            table#datatable>thead>tr,th {
                height: 0px !important;
            }

            table#datatable>tbody>tr {
                border: 1px solid #eee !important;
            }

            table#datatable>tbody>tr:active {
                --bs-table-accent-bg: none;
                background-color: #81d4fa!important;
                cursor: pointer;
                transition: 0.5s;
            }

            @media (max-width: 992px){
                .navbar-brand-box {
                    display: none !important;
                }

                .vertical-menu{
                    top: 0px !important;
                    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
                }

                .page-content{
                    padding-left: 0px !important;
                    padding-right: 0px !important;
                }

                #datatable_processing{
                    border: 2px solid #525ce5 !important;
                }

                
            }
        </style>


    </head>

    
    <body>

        <!-- Begin page -->
        <div id="layout-wrapper">