            <!-- ========== Left Sidebar Start ========== -->
            <div class="vertical-menu">

                <div data-simplebar class="h-100">


                    <div class="user-sidebar text-center">
                        <div class="dropdown">
                            <div class="user-img">
                                <img src="<?= base_url();?>assets/images/users/avatar-7.jpg" alt="" class="rounded-circle">
                                <span class="avatar-online bg-success"></span>
                            </div>
                            <div class="user-info">
                                <h5 class="mt-3 font-size-16 text-white">
                                    <?php
                                    //$this->session->userdata('name');
                                    echo 'Superadmin';
                                    ?> 
                                    </h5>
                                <span class="font-size-13 text-white-50">
                                    <?php
                                    //$this->session->userdata('role_name');
                                    echo 'Superadmin';
                                    ?>
                                    </span>
                            </div>
                        </div>
                    </div>



                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <!-- Left Menu Start -->
                        <ul class="metismenu list-unstyled" id="side-menu">
                            <li class="menu-title"></li>
                            <li class="app-dashboard">
                                <a href="<?= base_url();?>#app/dashboard" class="waves-effect">
                                    <i class="dripicons-home"></i>
                                    <span>Dashboard</span>
                                </a>
                            </li>
                            <li class="app-feed">
                                <a href="<?= base_url();?>#app/feed" class="waves-effect">
                                    <i class="dripicons-feed"></i>
                                    <span>Feed</span>
                                </a>
                            </li>
                            <!-- <li class="app-feed-search">
                                <a href="<?= base_url();?>#app/feed/search" class="waves-effect">
                                    <i class="dripicons-search"></i>
                                    <span>Search</span>
                                </a>
                            </li> -->
                            <li class="menu-title">Master Data</li>

                            <li class="app-user">
                                <a href="<?= base_url();?>#app/user" class=" waves-effect">
                                    <i class="dripicons-user-group"></i>
                                    <span>User Data</span>
                                </a>
                            </li>

                            <li class="app-hac">
                                <a href="<?= base_url();?>#app/hac" class=" waves-effect">
                                    <i class="dripicons-code"></i>
                                    <span>HAC List</span>
                                </a>
                            </li>

                            <li class="menu-title">Report</li>

                            <li class="app-feed-my_daily">
                                <a href="<?= base_url();?>#app/feed/my_daily" class=" waves-effect">
                                    <i class="dripicons-article"></i>
                                    <span>My Daily</span>
                                </a>
                            </li>

                            <li class="menu-title">Account</li>

                            <li class="profile">
                                <a href="<?= base_url();?>#profile" class=" waves-effect">
                                    <i class="dripicons-user"></i>
                                    <span>Profile</span>
                                </a>
                            </li>

                            <li>
                                <a href="<?= base_url();?>login/logout" class=" waves-effect">
                                    <i class="dripicons-exit"></i>
                                    <span>Logout</span>
                                </a>
                            </li>

                            <li class="menu-title">Application</li>

                            <li class="profile">
                                <a href="<?= base_url();?>#app/about" class=" waves-effect">
                                    <i class="dripicons-message"></i>
                                    <span>About</span>
                                </a>
                            </li>

                            <li>
                                <a href="<?= base_url();?>#app/help" class=" waves-effect">
                                    <i class="dripicons-question"></i>
                                    <span>Help ?</span>
                                </a>
                            </li>

                        </ul>
                    </div>
                    <!-- Sidebar -->
                </div>
            </div>
            <!-- Left Sidebar End -->
