<script type="text/javascript">
	$('#form_profile').on('submit', function(e){
		e.preventDefault();
		$('#btn_save').html('Saving...');
	    $('#btn_save').attr('disabled', 'disabled');
	    var url_data = '<?= base_url();?>profile/update';
	    $.ajax({
	        url: url_data,
	        type: "POST",
	        data: $('#form_profile').serialize(),
	        success: function(data_result) {
	          console.log('data '+data_result);
	          if (data_result=='1') {
	            Swal.fire(
	                  'Success!',
	                  'Data has been saved!',
	                  'success'
	            ).then(function() {
	                
	            });
	          }else if(data_result=='2'){
	            Swal.fire("Failed!", "New password not match!", "warning");
	          }else if(data_result=='3'){
	            Swal.fire("Failed!", "Old password not match!", "warning");
	          }else{
	            Swal.fire("Failed!", "Something wrong!", "warning");
	          }
	          $('#btn_save').html('Save Changes');
	          $('#btn_save').attr('disabled', false);
	        },
	        error: function(xhr, status, error) {
	          Swal.fire("Gagal!", "Oppss! Terjadi Kesalahan!", "warning");
	          $('#btn_save').html('Save Changes');
	          $('#btn_save').attr('disabled', false);
	        }
	    });
	});
</script>