            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

                <div class="page-content" id="tw_main_content">
                        <!-- content will be here!!-->
                </div>
                <!-- End Page-content -->

              
                
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-6">
                                
                            </div>
                            <div class="col-sm-6 text-right">
                                <!-- <div class="text-sm-end d-none d-sm-block">
                                    Developed with <i class="mdi mdi-heart text-danger"></i> by <a target="_blank" href="https://tubanweb.com" class="badge bg-danger">TubanWeb</a>
                                </div> -->
                                <script>document.write(new Date().getFullYear())</script> © <?= master_title();?>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
            <!-- end main content-->