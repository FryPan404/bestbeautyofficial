<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	public function index()
	{
		$data['title'] = 'User Data';
		$data['css_file'] = array('app/user/user.css');
		$data['js_file'] = array('app/user/user.js');
		$this->load->view('app/user/user', $data);
	}

	public function add()
	{
		$data['title'] = 'Add User';
		$data['css_file'] = array('app/user/user.css');
		$data['js_file'] = array('app/user/user.js');
		$this->load->view('app/user/user-add', $data);
	}

	public function edit()
	{
		$data['title'] = 'Edit User';
		$data['css_file'] = array('app/user/user.css');
		$data['js_file'] = array('app/user/user.js');
		$this->load->view('app/user/user-edit', $data);
	}

}

/* End of file User.php */
/* Location: ./application/controllers/app/User.php */