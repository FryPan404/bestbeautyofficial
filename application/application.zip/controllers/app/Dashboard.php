<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function index()
	{
		$data['title'] = 'Dashboard';
		$data['css_file'] = array('app/dashboard/dashboard.css');
		$data['js_file'] = array('app/dashboard/dashboard.js');
		$this->load->view('app/dashboard/dashboard', $data);
	}

}

/* End of file Dashboard.php */
/* Location: ./application/controllers/admin/Dashboard.php */