<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
        //is_logged_in();
		$this->load->model('Profile_model','Profile_model');
	}

	public function index()
	{
		$data['title'] = 'Profile';
		$this->load->view('profile', $data);
		$this->load->view('profile-js', $data);
	}

	public function update()
	{
		//echo $this->Profile_model->update();
	}

}

/* End of file Good_sales.php */
/* Location: ./application/controllers/admin/Good_sales.php */