<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Session_expired extends CI_Controller {

	public function index()
	{
		$data['title'] = 'Session Kadaluarsa';
		$this->load->view('session-expired', $data);
	}

}

/* End of file Session_expired.php */
/* Location: ./application/controllers/Session_expired.php */