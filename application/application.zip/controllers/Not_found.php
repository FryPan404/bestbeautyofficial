<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Not_found extends CI_Controller {

	public function index()
	{
		$data['title'] = 'Not Found';
		$this->load->view('auth/header', $data);
		$this->load->view('not-found', $data);
		$this->load->view('auth/footer', $data);
	}

}

/* End of file Not_found.php */
/* Location: ./application/controllers/Not_found.php */