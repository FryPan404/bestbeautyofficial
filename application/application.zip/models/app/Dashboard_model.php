<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard_model extends CI_Model {

	

}

/* End of file Dashboard_model.php */
/* Location: ./application/models/admin/Dashboard_model.php */