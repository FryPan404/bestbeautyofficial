<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile_model extends CI_Model {

	public function get_profile_data()
	{
		$this->db->select('tbl_user.*, tbl_role.name as role_name, tbl_warehouse.name as warehouse_name');
		$this->db->join('tbl_role', 'tbl_user.role_id = tbl_role.id', 'left');
		$this->db->join('tbl_warehouse', 'tbl_user.warehouse_id = tbl_warehouse.id', 'left');
		$this->db->where('tbl_user.id', $this->session->userdata('id'));
		return $this->db->get('tbl_user')->row_array();
	}

	public function update()
	{
		$name = $this->input->post('name');
		$password = $this->input->post('password');
		$new_password = $this->input->post('new_password');

		$this->db->where('id', $this->session->userdata('id'));
		$user = $this->db->get('tbl_user')->row_array();

		if (password_verify($password, $user['password'])) {
            //continue
        }else{
        	return '3';
        	exit();
        }

		if ($this->input->post('new_password')=='') {
            $data = array(
                'name' => $this->input->post('name')
            );
        }else{
            $data = array(
                'name' => $this->input->post('name'),
                'password' => password_hash($this->input->post('new_password'), PASSWORD_DEFAULT)
            );
        }

        if ($this->input->post('name')=='') {
            $result='0';
        }else{
            $this->db->where('id', $this->session->userdata('id'));
            $result = $this->db->update('tbl_user', $data);
        }
        return $result;
	}

}

/* End of file Profile_model.php */
/* Location: ./application/models/Profile_model.php */