<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Login_model extends CI_Model
{
    public function g_login()
    {
        $email = $this->input->post('username', true);
        $password = $this->input->post('password', true);
        $this->db->select('tbl_user.*, tbl_role.name as role_name');
        $this->db->where('tbl_user.username', $email);
        $this->db->join('tbl_role', 'tbl_user.role_id = tbl_role.id', 'left');
        $this->db->limit(1);
        $this->db->order_by('tbl_user.id', 'asc');
        $user = $this->db->get('tbl_user')->row_array();
        if ($user) {
            if ($user['login_attempt']<=0) {
                $this->session->set_flashdata(
                    'pesan',
                    '<div class="alert alert-danger alert-dismissible fade show mb-3" role="alert">
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                          
                        </button>
                        You try too much! Maximum login attempt reached.
                    </div>'
                );
                redirect('login');
            }else{
                if ($user['is_active'] == 1) {
                    if (password_verify($password, $user['password'])) {
                        if ($user['role_id'] <=10) {
                            $data = [
                                'id' => $user['id'],
                                'username' => $user['username'],
                                'name' => $user['name'],
                                'warehouse_id' => $user['warehouse_id'],
                                'role_id' => $user['role_id'],
                                'role_name' => $user['role_name']
                            ];
                            $this->session->set_userdata($data);
                            $data=[
                                'login_attempt' => '5'
                            ];
                            $this->db->where('id', $user['id']);
                            $this->db->update('tbl_user', $data);
                            redirect(base_url('#home'));
                        } else {

                        }
                    } else {
                        $data=[
                            'login_attempt' => intval($user['login_attempt']) - 1
                        ];
                        $this->db->where('id', $user['id']);
                        $this->db->update('tbl_user', $data);
                        $this->session->set_flashdata(
                            'pesan',
                            '<div class="alert alert-danger alert-dismissible fade show mb-3" role="alert">
	                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
	                              
	                            </button>
	                            Invalid password!!!
	                        </div>'
                        );
                        redirect('login');
                    }
                } else {
                    $this->session->set_flashdata(
                        'pesan',
                        '<div class="alert alert-danger alert-dismissible fade show mb-3" role="alert">
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                              
                            </button>
                            Your account is inactive!
                        </div>'
                    );
                    redirect('login');
                }
            }
        } else {
            $this->session->set_flashdata(
                'pesan',
                '<div class="alert alert-danger alert-dismissible fade show mb-3" role="alert">
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                      
                    </button>
                    You are not registered!
                </div>'
            );
            redirect('login');
        }
    }
}
