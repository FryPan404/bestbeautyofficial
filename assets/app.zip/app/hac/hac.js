$(document).ready( function () {
    $('#hac_table').DataTable();
});