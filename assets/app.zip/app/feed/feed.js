$(document).ready( function () {
    $('#feed_table').DataTable();
});