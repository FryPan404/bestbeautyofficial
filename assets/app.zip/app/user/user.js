$(document).ready( function () {
    $('#user_table').DataTable();
});